# Smart Stock build

- [x] Create Lovable Cloud schema for profiles, roles, inventory, operations, alerts, expiry, and hardware readiness.
- [x] Add email/password and Google sign-in with profile-aware session state.
- [x] Build the Smart Stock dashboard shell and interactive inventory workflows.
- [ ] Add route metadata, validate preview, and resolve build/runtime issues.
