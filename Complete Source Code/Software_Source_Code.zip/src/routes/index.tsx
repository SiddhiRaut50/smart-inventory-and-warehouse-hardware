import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  AlertTriangle,
  ArrowDownToLine,
  ArrowUpFromLine,
  BarChart3,
  Bell,
  Boxes,
  ChevronDown,
  CircleUserRound,
  Cpu,
  Database,
  LogIn,
  LogOut,
  Menu,
  PackageCheck,
  PackageOpen,
  PanelLeft,
  Plus,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  ShoppingCart,
  Tags,
  Truck,
  UserRound,
  X,
  Zap,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Smart Stock Dashboard | Warehouse Control Room" },
      {
        name: "description",
        content: "Smart Stock is a practical inventory control room for products, stock movement, alerts, and future hardware readiness.",
      },
      { property: "og:title", content: "Smart Stock Dashboard" },
      {
        property: "og:description",
        content: "Manage warehouse inventory, stock movement, reorder alerts, and device readiness in one place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SmartStock,
});

type NavItem = "Overview" | "Products" | "Stock IN" | "Stock OUT" | "Reorder rules" | "Devices";
type ProductStatus = "OK" | "Low" | "Expiry" | "Out";
type MovementType = "Stock IN" | "Stock OUT";

type Product = {
  sku: string;
  name: string;
  category: string;
  bin: string;
  qty: number;
  unit: string;
  reorder: number;
  price: number;
  status: ProductStatus;
  expiry?: string;
};

type Movement = {
  id: string;
  product: string;
  type: MovementType;
  qty: number;
  source: string;
  time: string;
};

const initialProducts: Product[] = [
  { sku: "SKU-0092", name: "Basmati rice 5kg", category: "Grains", bin: "12-B", qty: 18, unit: "bag", reorder: 30, price: 685, status: "Low" },
  { sku: "SKU-0140", name: "Sunflower oil 1L", category: "Oils", bin: "07-A", qty: 240, unit: "bottle", reorder: 80, price: 152, status: "OK" },
  { sku: "SKU-0031", name: "Toor dal 1kg", category: "Pulses", bin: "03-C", qty: 9, unit: "bag", reorder: 25, price: 148, status: "Low" },
  { sku: "SKU-0207", name: "Fresh milk 500ml", category: "Dairy", bin: "01-R", qty: 64, unit: "pack", reorder: 40, price: 32, status: "Expiry", expiry: "2 days" },
  { sku: "SKU-0118", name: "Sugar 2kg", category: "Staples", bin: "05-B", qty: 312, unit: "bag", reorder: 75, price: 118, status: "OK" },
  { sku: "SKU-0064", name: "Yogurt tub 400g", category: "Dairy", bin: "01-R", qty: 22, unit: "tub", reorder: 35, price: 64, status: "Expiry", expiry: "4 days" },
  { sku: "SKU-0181", name: "Chickpeas 1kg", category: "Pulses", bin: "03-C", qty: 0, unit: "bag", reorder: 20, price: 128, status: "Out" },
];

const barHeights = [42, 66, 54, 88, 60, 74, 50, 96, 70, 58, 82, 46, 72, 64];
const navItems: { label: NavItem; icon: typeof Boxes }[] = [
  { label: "Overview", icon: BarChart3 },
  { label: "Products", icon: Boxes },
  { label: "Stock IN", icon: ArrowDownToLine },
  { label: "Stock OUT", icon: ArrowUpFromLine },
  { label: "Reorder rules", icon: RefreshCw },
  { label: "Devices", icon: Cpu },
];

function SmartStock() {
  const [activeNav, setActiveNav] = useState<NavItem>("Overview");
  const [products, setProducts] = useState(initialProducts);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | ProductStatus>("All");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [movementType, setMovementType] = useState<MovementType | null>(null);
  const [selectedProduct, setSelectedProduct] = useState(initialProducts[0]?.sku ?? "");
  const [movementQty, setMovementQty] = useState("1");
  const [movements, setMovements] = useState<Movement[]>([
    { id: "TX-1047", product: "Sunflower oil 1L", type: "Stock IN", qty: 120, source: "Manual", time: "09:32" },
    { id: "TX-1046", product: "Fresh milk 500ml", type: "Stock OUT", qty: 24, source: "Sale", time: "09:18" },
    { id: "TX-1045", product: "Basmati rice 5kg", type: "Stock IN", qty: 30, source: "Purchase", time: "Yesterday" },
  ]);
  const [user, setUser] = useState<{ email: string; name?: string } | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"sign-in" | "sign-up">("sign-in");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authMessage, setAuthMessage] = useState("");
  const [authBusy, setAuthBusy] = useState(false);

  useEffect(() => {
    let mounted = true;
    void supabase.auth.getUser().then(({ data }) => {
      if (mounted && data.user?.email) {
        setUser({ email: data.user.email, name: data.user.user_metadata?.["full_name"] });
      }
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted) return;
      setUser(session?.user?.email ? { email: session.user.email, name: session.user.user_metadata?.["full_name"] } : null);
    });
    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  const filteredProducts = useMemo(() => {
    const query = search.trim().toLowerCase();
    return products.filter((product) => {
      const matchesSearch = !query || [product.name, product.sku, product.category, product.bin].some((value) => value.toLowerCase().includes(query));
      const matchesStatus = statusFilter === "All" || product.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [products, search, statusFilter]);

  const stats = useMemo(() => {
    const totalQuantity = products.reduce((total, product) => total + product.qty, 0);
    const value = products.reduce((total, product) => total + product.qty * product.price, 0);
    return {
      totalQuantity,
      value,
      low: products.filter((product) => product.status === "Low").length,
      out: products.filter((product) => product.status === "Out").length,
      expiry: products.filter((product) => product.status === "Expiry").length,
    };
  }, [products]);

  const applyMovement = () => {
    if (!movementType) return;
    const qty = Number(movementQty);
    if (!Number.isFinite(qty) || qty <= 0) return;
    const chosen = products.find((product) => product.sku === selectedProduct);
    if (!chosen) return;
    const nextQuantity = movementType === "Stock IN" ? chosen.qty + qty : Math.max(0, chosen.qty - qty);
    setProducts((current) => current.map((product) => product.sku === selectedProduct ? { ...product, qty: nextQuantity, status: nextStatus(nextQuantity, product.reorder, product.status) } : product));
    setMovements((current) => [{ id: `TX-${1048 + current.length}`, product: chosen.name, type: movementType, qty, source: "Manual", time: "Just now" }, ...current]);
    setMovementType(null);
    setMovementQty("1");
  };

  const submitAuth = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setAuthBusy(true);
    setAuthMessage("");
    const result = authMode === "sign-in"
      ? await supabase.auth.signInWithPassword({ email: authEmail, password: authPassword })
      : await supabase.auth.signUp({ email: authEmail, password: authPassword, options: { data: { full_name: authName }, emailRedirectTo: window.location.origin } });
    setAuthBusy(false);
    if (result.error) {
      setAuthMessage(result.error.message);
      return;
    }
    if (authMode === "sign-up" && !result.data.session) {
      setAuthMessage("Account created. Check your email to confirm access.");
      return;
    }
    setAuthMessage("Signed in successfully.");
    setAuthOpen(false);
  };

  const signInWithGoogle = async () => {
    setAuthMessage("");
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result.error) setAuthMessage(result.error.message);
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  return (
    <div className="min-h-screen bg-paper text-ink font-sans">
      <div className="flex min-h-screen">
        <aside className={cn("fixed inset-y-0 left-0 z-40 flex w-60 shrink-0 -translate-x-full flex-col bg-ink p-5 text-primary-foreground transition-transform lg:static lg:translate-x-0", mobileNavOpen && "translate-x-0")}>
          <div className="flex items-center gap-2.5">
            <div className="grid size-9 place-items-center rounded-[10px] bg-coral font-display text-lg font-bold text-primary-foreground">S</div>
            <div className="leading-tight">
              <div className="font-display text-[15px] font-bold">Smart Stock</div>
              <div className="text-[10px] uppercase tracking-[0.18em] text-primary-foreground/40">Warehouse OS</div>
            </div>
          </div>
          <div className="mt-8 text-[10px] font-bold uppercase tracking-[0.18em] text-primary-foreground/40">Control room</div>
          <nav className="mt-2 space-y-1 text-sm" aria-label="Main navigation">
            {navItems.map(({ label, icon: Icon }) => (
              <Button key={label} variant="ghost" className={cn("w-full justify-start rounded-[12px] px-3 py-2.5 font-medium text-primary-foreground/60 hover:bg-primary-foreground/10 hover:text-primary-foreground", activeNav === label && "bg-brand text-primary-foreground hover:bg-brand hover:text-primary-foreground")} onClick={() => { setActiveNav(label); setMobileNavOpen(false); }}>
                <Icon />{label}
              </Button>
            ))}
          </nav>
          <div className="mt-8 text-[10px] font-bold uppercase tracking-[0.18em] text-primary-foreground/40">System</div>
          <div className="mt-2 space-y-1 text-sm">
            <Button variant="ghost" className="w-full justify-start rounded-[12px] px-3 py-2.5 font-medium text-primary-foreground/60 hover:bg-primary-foreground/10 hover:text-primary-foreground"><Bell />Alerts <span className="ml-auto rounded-full bg-coral px-2 py-0.5 text-[10px] text-primary-foreground">3</span></Button>
            <Button variant="ghost" className="w-full justify-start rounded-[12px] px-3 py-2.5 font-medium text-primary-foreground/60 hover:bg-primary-foreground/10 hover:text-primary-foreground"><Settings2 />Settings</Button>
          </div>
          <div className="mt-auto rounded-[14px] bg-primary-foreground/5 p-3 ring-1 ring-primary-foreground/10">
            <div className="flex items-center gap-2 text-[11px] font-medium text-mint"><span className="size-2 rounded-full bg-mint" /> RFID scanner · ready</div>
            <div className="mt-1.5 text-[11px] leading-pretty text-primary-foreground/40">Hardware connections are prepared for future ESP32 integration.</div>
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 flex min-h-[66px] items-center gap-3 bg-panel px-4 py-3 shadow-sm ring-1 ring-ink/5 sm:px-6">
            <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open navigation" onClick={() => setMobileNavOpen(true)}><Menu /></Button>
            <div className="flex items-center gap-2 text-sm font-medium"><span className="hidden text-ink/40 sm:inline">Warehouse /</span> Aisle 4 · Bin 12-B</div>
            <div className="ml-auto flex items-center gap-2">
              <span className="hidden items-center gap-1.5 rounded-full bg-ink px-3 py-2 text-xs font-medium text-primary-foreground/70 sm:inline-flex"><span className="size-1.5 rounded-full bg-citrus" /> 3 low-stock</span>
              <Button variant="outline" size="sm" className="hidden rounded-full border-coral text-coral hover:bg-coral/10 sm:inline-flex" onClick={() => setMovementType("Stock OUT")}><ArrowUpFromLine />Stock OUT</Button>
              <Button size="sm" className="rounded-full bg-brand text-primary-foreground hover:bg-brand/90" onClick={() => setMovementType("Stock IN")}><ArrowDownToLine />Stock IN</Button>
              <Button variant="ghost" size="icon" aria-label="Account" onClick={() => setAuthOpen(true)}>{user ? <CircleUserRound /> : <LogIn />}</Button>
            </div>
          </header>

          <main className="space-y-5 overflow-x-hidden p-4 sm:p-6">
            <div className="flex items-end justify-between gap-4 motion-safe:animate-[rise-in_.5s_ease_both]">
              <div>
                <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-ink/40">Warehouse control room</div>
                <h1 className="mt-1 max-w-[16ch] font-display text-5xl font-bold leading-[0.92] sm:text-7xl">{activeNav === "Overview" ? "Bin board" : activeNav}</h1>
              </div>
              <div className="hidden max-w-[30ch] text-right text-xs text-ink/50 sm:block">Live operations · updated 09:41<br /><span className="text-mint">●</span> Demo mode · data actions are ready to connect</div>
            </div>

            <section className="grid grid-cols-2 gap-3 lg:grid-cols-5">
              <Metric label="SKUs" value="1,284" tone="citrus" />
              <Metric label="In stock" value={stats.totalQuantity.toLocaleString()} tone="mint" />
              <Metric label="Low stock" value={stats.low.toString()} tone="coral" inverse />
              <Metric label="Expiring 7d" value={stats.expiry.toString()} tone="panel" />
              <Metric label="Value" value={`₹${(stats.value / 1000000).toFixed(1)}M`} tone="ink" inverse />
            </section>

            {activeNav === "Overview" && <OverviewContent onReorder={() => setActiveNav("Reorder rules")} />}
            {activeNav === "Products" && <ProductsContent products={filteredProducts} search={search} setSearch={setSearch} statusFilter={statusFilter} setStatusFilter={setStatusFilter} onStockIn={() => setMovementType("Stock IN")} onStockOut={() => setMovementType("Stock OUT")} />}
            {activeNav === "Stock IN" && <MovementContent type="Stock IN" movements={movements} onOpen={() => setMovementType("Stock IN")} />}
            {activeNav === "Stock OUT" && <MovementContent type="Stock OUT" movements={movements} onOpen={() => setMovementType("Stock OUT")} />}
            {activeNav === "Reorder rules" && <ReorderContent products={products} onOpen={() => setMovementType("Stock IN")} />}
            {activeNav === "Devices" && <DevicesContent />}
          </main>
        </div>
      </div>

      {mobileNavOpen && <Button variant="ghost" className="fixed inset-0 z-30 h-auto w-full rounded-none bg-ink/30 lg:hidden" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)} />}
      {movementType && <MovementDialog type={movementType} products={products} selectedProduct={selectedProduct} setSelectedProduct={setSelectedProduct} movementQty={movementQty} setMovementQty={setMovementQty} onClose={() => setMovementType(null)} onSubmit={applyMovement} />}
      {authOpen && <AuthDialog user={user} mode={authMode} setMode={setAuthMode} email={authEmail} setEmail={setAuthEmail} password={authPassword} setPassword={setAuthPassword} name={authName} setName={setAuthName} message={authMessage} busy={authBusy} onClose={() => setAuthOpen(false)} onSubmit={submitAuth} onGoogle={signInWithGoogle} onSignOut={signOut} />}
    </div>
  );
}

function nextStatus(qty: number, reorder: number, existing: ProductStatus): ProductStatus {
  if (qty === 0) return "Out";
  if (existing === "Expiry") return existing;
  if (qty <= reorder) return "Low";
  return "OK";
}

function Metric({ label, value, tone, inverse = false }: { label: string; value: string; tone: "citrus" | "mint" | "coral" | "panel" | "ink"; inverse?: boolean }) {
  return <div className={cn("rounded-[18px] p-4 ring-1 ring-ink/5", tone === "citrus" && "bg-citrus", tone === "mint" && "bg-mint", tone === "coral" && "bg-coral", tone === "panel" && "bg-panel", tone === "ink" && "bg-ink", inverse && "text-primary-foreground")}><div className={cn("text-[10px] font-bold uppercase tracking-[0.15em]", inverse ? "text-primary-foreground/75" : "text-ink/60")}>{label}</div><div className="mt-1 font-display text-4xl font-bold leading-none">{value}</div></div>;
}

function OverviewContent({ onReorder }: { onReorder: () => void }) {
  return <>
    <section className="grid gap-4 lg:grid-cols-3">
      <div className="rounded-[20px] bg-panel p-5 shadow-sm ring-1 ring-ink/5 lg:col-span-2">
        <div className="flex items-baseline justify-between"><h2 className="font-display text-lg font-semibold">Stock movement · 14d</h2><div className="text-xs text-ink/50">IN <span className="text-brand">▮</span> · OUT <span className="text-coral">▮</span></div></div>
        <div className="mt-5 flex h-44 items-end gap-1.5">{barHeights.map((height, index) => <div key={index} className="rise flex-1 rounded-t-md bg-brand/25" style={{ height: `${height}%`, animationDelay: `${index * 30}ms` }} />)}</div>
        <div className="mt-2 flex justify-between text-[10px] uppercase tracking-[0.12em] text-ink/35"><span>14 days ago</span><span>Today</span></div>
      </div>
      <div className="rounded-[20px] bg-panel p-5 shadow-sm ring-1 ring-ink/5"><h2 className="font-display text-lg font-semibold">Expiry watch</h2><div className="mt-3 space-y-3 text-sm"><ExpiryRow label="Fresh milk 500ml" days="2d" urgent /><ExpiryRow label="Yogurt tub · 400g" days="4d" urgent /><ExpiryRow label="Paneer block · 1kg" days="6d" /><ExpiryRow label="Fresh cream · 250ml" days="7d" /></div><Button className="mt-4 w-full rounded-full bg-ink text-xs text-primary-foreground hover:bg-ink/90" onClick={onReorder}>Reorder flagged</Button></div>
    </section>
    <section className="rounded-[20px] bg-panel p-5 shadow-sm ring-1 ring-ink/5"><div className="flex flex-wrap items-center justify-between gap-3"><h2 className="font-display text-lg font-semibold">Inventory · attention</h2><Button variant="outline" size="sm" className="rounded-full" onClick={onReorder}><PackageCheck /> View reorder queue</Button></div><InventoryTable products={initialProducts.slice(0, 5)} /></section>
  </>;
}

function ExpiryRow({ label, days, urgent = false }: { label: string; days: string; urgent?: boolean }) { return <div className="flex items-center justify-between"><span className="text-ink/70">{label}</span><span className={cn("font-semibold", urgent ? "text-coral" : "text-citrus")}>{days}</span></div>; }

function InventoryTable({ products }: { products: Product[] }) { return <div className="mt-3 overflow-x-auto"><table className="w-full min-w-[640px] text-sm"><thead className="text-[10px] uppercase tracking-[0.14em] text-ink/40"><tr><th className="py-2 text-left font-bold">SKU</th><th className="py-2 text-left font-bold">Product</th><th className="py-2 text-left font-bold">Bin</th><th className="py-2 text-left font-bold">Qty</th><th className="py-2 text-left font-bold">Status</th></tr></thead><tbody>{products.map((product) => <tr key={product.sku} className="border-t border-ink/5"><td className="py-2.5 font-medium">{product.sku}</td><td className="py-2.5">{product.name}</td><td className="py-2.5">{product.bin}</td><td className="py-2.5">{product.qty} {product.unit}s</td><td className="py-2.5"><StatusBadge status={product.status} /></td></tr>)}</tbody></table></div>; }

function ProductsContent({ products, search, setSearch, statusFilter, setStatusFilter, onStockIn, onStockOut }: { products: Product[]; search: string; setSearch: (value: string) => void; statusFilter: "All" | ProductStatus; setStatusFilter: (value: "All" | ProductStatus) => void; onStockIn: () => void; onStockOut: () => void }) {
  return <section className="rounded-[20px] bg-panel p-5 shadow-sm ring-1 ring-ink/5"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-lg font-semibold">Product inventory</h2><p className="mt-1 text-sm text-ink/50">Search by name, SKU, category, or bin location.</p></div><div className="flex gap-2"><Button size="sm" variant="outline" className="rounded-full border-coral text-coral hover:bg-coral/10" onClick={onStockOut}><ArrowUpFromLine /> Stock OUT</Button><Button size="sm" className="rounded-full bg-brand text-primary-foreground hover:bg-brand/90" onClick={onStockIn}><Plus /> Stock IN</Button></div></div><div className="mt-5 flex flex-wrap gap-2"><label className="flex min-w-[240px] flex-1 items-center gap-2 rounded-full border border-input bg-background px-3"><Search className="size-4 text-ink/40" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search products" className="h-9 w-full bg-transparent text-sm outline-none placeholder:text-ink/35" /></label>{["All", "OK", "Low", "Expiry", "Out"].map((status) => <Button key={status} size="sm" variant={statusFilter === status ? "default" : "outline"} className="rounded-full" onClick={() => setStatusFilter(status as "All" | ProductStatus)}>{status}</Button>)}</div><div className="mt-3 overflow-x-auto"><table className="w-full min-w-[850px] text-sm"><thead className="text-[10px] uppercase tracking-[0.14em] text-ink/40"><tr><th className="py-2 text-left">SKU</th><th className="text-left">Product</th><th className="text-left">Category</th><th className="text-left">Bin</th><th className="text-left">Current stock</th><th className="text-left">Reorder at</th><th className="text-left">Status</th></tr></thead><tbody>{products.map((product) => <tr key={product.sku} className="border-t border-ink/5"><td className="py-3 font-medium">{product.sku}</td><td>{product.name}</td><td>{product.category}</td><td>{product.bin}</td><td>{product.qty} {product.unit}s</td><td>{product.reorder}</td><td><StatusBadge status={product.status} /></td></tr>)}</tbody></table>{products.length === 0 && <div className="py-10 text-center text-sm text-ink/50">No products match those filters.</div>}</div></section>;
}

function StatusBadge({ status }: { status: ProductStatus }) { return <span className={cn("inline-flex rounded-full px-2 py-1 text-[10px] font-bold", status === "Low" && "bg-coral text-primary-foreground", status === "Out" && "bg-ink text-primary-foreground", status === "Expiry" && "bg-citrus text-ink", status === "OK" && "bg-mint/15 text-mint")}>{status}</span>; }

function MovementContent({ type, movements, onOpen }: { type: MovementType; movements: Movement[]; onOpen: () => void }) { const rows = movements.filter((movement) => movement.type === type); return <section className="rounded-[20px] bg-panel p-5 shadow-sm ring-1 ring-ink/5"><div className="flex flex-wrap items-center justify-between gap-3"><div><div className="flex items-center gap-2"><span className={cn("grid size-9 place-items-center rounded-full", type === "Stock IN" ? "bg-brand/10 text-brand" : "bg-coral/10 text-coral")} >{type === "Stock IN" ? <ArrowDownToLine /> : <ArrowUpFromLine />}</span><h2 className="font-display text-lg font-semibold">{type} movement</h2></div><p className="mt-2 text-sm text-ink/50">Manual capture is active. The RFID endpoint is prepared for future device calls.</p></div><Button className={cn("rounded-full text-primary-foreground", type === "Stock IN" ? "bg-brand hover:bg-brand/90" : "bg-coral hover:bg-coral/90")} onClick={onOpen}><Plus /> Record {type}</Button></div><div className="mt-6 space-y-2">{rows.map((movement) => <div key={movement.id} className="flex flex-wrap items-center gap-4 border-t border-ink/5 py-3 text-sm"><span className="font-mono text-xs text-ink/40">{movement.id}</span><span className="min-w-[180px] font-medium">{movement.product}</span><span>{movement.qty} units</span><span className="rounded-full bg-muted px-2 py-1 text-xs">{movement.source}</span><span className="ml-auto text-xs text-ink/45">{movement.time}</span></div>)}</div></section>; }

function ReorderContent({ products, onOpen }: { products: Product[]; onOpen: () => void }) { const rows = products.filter((product) => product.status === "Low" || product.status === "Out"); return <section className="rounded-[20px] bg-panel p-5 shadow-sm ring-1 ring-ink/5"><div className="flex items-center justify-between"><div><h2 className="font-display text-lg font-semibold">Reorder queue</h2><p className="mt-1 text-sm text-ink/50">Recommendations are rule-based, not AI-generated.</p></div><Button className="rounded-full bg-brand text-primary-foreground hover:bg-brand/90" onClick={onOpen}><ShoppingCart /> Start purchase</Button></div><div className="mt-5 grid gap-3 md:grid-cols-2">{rows.map((product) => <div key={product.sku} className="rounded-[14px] border border-ink/10 p-4"><div className="flex items-start justify-between gap-3"><div><div className="font-medium">{product.name}</div><div className="mt-1 text-xs text-ink/45">{product.sku} · {product.category}</div></div><StatusBadge status={product.status} /></div><div className="mt-4 grid grid-cols-3 gap-3 text-sm"><div><div className="text-[10px] uppercase tracking-wider text-ink/40">Current</div><div className="font-display text-xl font-semibold">{product.qty}</div></div><div><div className="text-[10px] uppercase tracking-wider text-ink/40">Reorder at</div><div className="font-display text-xl font-semibold">{product.reorder}</div></div><div><div className="text-[10px] uppercase tracking-wider text-ink/40">Suggested</div><div className="font-display text-xl font-semibold text-brand">{Math.max(product.reorder * 2 - product.qty, product.reorder)}</div></div></div></div>)}</div></section>; }

function DevicesContent() { const devices = [{ name: "ESP32 Gateway 01", code: "ESP32-GW-01", type: "ESP32", location: "Aisle 4", status: "Planned", reading: "No readings yet" }, { name: "RFID Station 01", code: "RFID-RC522-01", type: "RFID RC522", location: "Stock IN desk", status: "Planned", reading: "Simulation ready" }, { name: "Load Cell Bay 02", code: "HX711-LC-02", type: "Load Cell + HX711", location: "Aisle 7", status: "Planned", reading: "No readings yet" }]; return <section className="rounded-[20px] bg-panel p-5 shadow-sm ring-1 ring-ink/5"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-lg font-semibold">Hardware readiness</h2><p className="mt-1 text-sm text-ink/50">Device models and endpoints are ready; physical hardware is not connected.</p></div><span className="rounded-full bg-citrus px-3 py-1 text-xs font-semibold text-ink">DEMO / SIMULATION</span></div><div className="mt-5 grid gap-3 md:grid-cols-3">{devices.map((device) => <div key={device.code} className="rounded-[14px] border border-dashed border-ink/15 p-4"><div className="flex items-center justify-between"><span className="grid size-9 place-items-center rounded-full bg-ink text-primary-foreground"><Cpu /></span><span className="text-xs font-semibold text-ink/45">{device.status}</span></div><div className="mt-4 font-medium">{device.name}</div><div className="mt-1 font-mono text-[11px] text-ink/45">{device.code}</div><div className="mt-4 space-y-2 text-xs text-ink/60"><div className="flex justify-between"><span>Type</span><span className="font-medium text-ink">{device.type}</span></div><div className="flex justify-between"><span>Location</span><span className="font-medium text-ink">{device.location}</span></div><div className="flex justify-between"><span>Last reading</span><span className="font-medium text-ink">{device.reading}</span></div></div></div>)}</div></section>; }

function MovementDialog({ type, products, selectedProduct, setSelectedProduct, movementQty, setMovementQty, onClose, onSubmit }: { type: MovementType; products: Product[]; selectedProduct: string; setSelectedProduct: (value: string) => void; movementQty: string; setMovementQty: (value: string) => void; onClose: () => void; onSubmit: () => void }) { return <div className="fixed inset-0 z-50 grid place-items-center bg-ink/35 p-4"><div className="w-full max-w-md rounded-[20px] bg-panel p-5 shadow-2xl"><div className="flex items-start justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[0.18em] text-ink/40">Manual transaction</div><h2 className="mt-1 font-display text-2xl font-semibold">Record {type}</h2></div><Button variant="ghost" size="icon" aria-label="Close" onClick={onClose}><X /></Button></div><div className="mt-5 space-y-4"><label className="block text-sm font-medium">Product<select value={selectedProduct} onChange={(event) => setSelectedProduct(event.target.value)} className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm">{products.map((product) => <option key={product.sku} value={product.sku}>{product.name} · {product.sku}</option>)}</select></label><label className="block text-sm font-medium">Quantity<input type="number" min="1" value={movementQty} onChange={(event) => setMovementQty(event.target.value)} className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm" /></label></div><div className="mt-6 flex justify-end gap-2"><Button variant="outline" className="rounded-full" onClick={onClose}>Cancel</Button><Button className={cn("rounded-full text-primary-foreground", type === "Stock IN" ? "bg-brand hover:bg-brand/90" : "bg-coral hover:bg-coral/90")} onClick={onSubmit}>Save transaction</Button></div></div></div>; }

function AuthDialog({ user, mode, setMode, email, setEmail, password, setPassword, name, setName, message, busy, onClose, onSubmit, onGoogle, onSignOut }: { user: { email?: string; name?: string } | null; mode: "sign-in" | "sign-up"; setMode: (value: "sign-in" | "sign-up") => void; email: string; setEmail: (value: string) => void; password: string; setPassword: (value: string) => void; name: string; setName: (value: string) => void; message: string; busy: boolean; onClose: () => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void; onGoogle: () => void; onSignOut: () => void }) { return <div className="fixed inset-0 z-50 grid place-items-center bg-ink/35 p-4"><div className="w-full max-w-md rounded-[20px] bg-panel p-5 shadow-2xl"><div className="flex items-start justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[0.18em] text-ink/40">Smart Stock access</div><h2 className="mt-1 font-display text-2xl font-semibold">{user ? "Account" : mode === "sign-in" ? "Sign in" : "Create account"}</h2></div><Button variant="ghost" size="icon" aria-label="Close" onClick={onClose}><X /></Button></div>{user ? <div className="mt-6"><div className="flex items-center gap-3 rounded-[14px] bg-muted p-3"><span className="grid size-10 place-items-center rounded-full bg-brand text-primary-foreground"><UserRound /></span><div><div className="font-medium">{user.name || "Warehouse user"}</div><div className="text-sm text-ink/50">{user.email}</div></div></div><Button variant="outline" className="mt-4 w-full rounded-full" onClick={onSignOut}><LogOut /> Sign out</Button></div> : <><form className="mt-5 space-y-4" onSubmit={onSubmit}>{mode === "sign-up" && <label className="block text-sm font-medium">Display name<input required value={name} onChange={(event) => setName(event.target.value)} className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm" placeholder="Warehouse lead" /></label>}<label className="block text-sm font-medium">Email<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm" placeholder="you@company.com" /></label><label className="block text-sm font-medium">Password<input required type="password" minLength={6} value={password} onChange={(event) => setPassword(event.target.value)} className="mt-2 h-10 w-full rounded-md border border-input bg-background px-3 text-sm" placeholder="At least 6 characters" /></label>{message && <div className="rounded-md bg-citrus/25 px-3 py-2 text-sm text-ink">{message}</div>}<Button disabled={busy} className="w-full rounded-full bg-brand text-primary-foreground hover:bg-brand/90">{busy ? "Working…" : mode === "sign-in" ? "Sign in" : "Create account"}</Button></form><div className="my-4 flex items-center gap-3 text-xs text-ink/35"><span className="h-px flex-1 bg-ink/10" />or<span className="h-px flex-1 bg-ink/10" /></div><Button variant="outline" className="w-full rounded-full" onClick={onGoogle}><ShieldCheck /> Continue with Google</Button><Button variant="link" className="mt-3 w-full text-xs" onClick={() => setMode(mode === "sign-in" ? "sign-up" : "sign-in")}>{mode === "sign-in" ? "Need a warehouse account? Create one" : "Already registered? Sign in"}</Button></>}</div></div>; }
