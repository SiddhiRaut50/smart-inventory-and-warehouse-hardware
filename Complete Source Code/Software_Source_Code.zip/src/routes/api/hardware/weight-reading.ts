import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const payloadSchema = z.object({
  deviceId: z.string().min(1),
  productId: z.string().uuid(),
  weight: z.number().nonnegative(),
  unit: z.string().min(1),
  timestamp: z.string().datetime().optional(),
});

export const Route = createFileRoute("/api/hardware/weight-reading")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = await request.json().catch(() => null);
        const parsed = payloadSchema.safeParse(body);
        if (!parsed.success) return Response.json({ error: "Invalid weight reading payload", details: parsed.error.flatten() }, { status: 400 });
        return Response.json({ accepted: false, mode: "simulation", message: "Weight-reading endpoint is ready for HX711 and Load Cell integration.", payload: parsed.data }, { status: 202 });
      },
    },
  },
});
