import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const payloadSchema = z.object({
  deviceId: z.string().min(1),
  rfidTagId: z.string().min(1),
  productId: z.string().uuid(),
  quantity: z.number().positive(),
  timestamp: z.string().datetime().optional(),
});

export const Route = createFileRoute("/api/hardware/rfid/stock-out")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = await request.json().catch(() => null);
        const parsed = payloadSchema.safeParse(body);
        if (!parsed.success) return Response.json({ error: "Invalid RFID stock-out payload", details: parsed.error.flatten() }, { status: 400 });
        return Response.json({ accepted: false, mode: "simulation", message: "RFID stock-out endpoint is ready; stock validation will run when hardware is connected.", payload: parsed.data }, { status: 202 });
      },
    },
  },
});
