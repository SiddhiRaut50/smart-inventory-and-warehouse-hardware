CREATE OR REPLACE FUNCTION public.is_warehouse_member(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin','warehouse_staff'))
$$;
REVOKE EXECUTE ON FUNCTION public.is_warehouse_member(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_warehouse_member(uuid) TO authenticated;

DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM (VALUES
    ('alerts','Authenticated users can manage alerts'),
    ('categories','Authenticated users can manage categories'),
    ('expiry_records','Authenticated users can manage expiry records'),
    ('hardware_devices','Authenticated users can manage hardware devices'),
    ('inventory','Authenticated users can manage inventory'),
    ('products','Authenticated users can manage products'),
    ('purchase_items','Authenticated users can manage purchase items'),
    ('purchases','Authenticated users can manage purchases'),
    ('reorder_rules','Authenticated users can manage reorder rules'),
    ('rfid_tags','Authenticated users can manage RFID tags'),
    ('sale_items','Authenticated users can manage sale items'),
    ('sales','Authenticated users can manage sales'),
    ('sensor_readings','Authenticated users can manage sensor readings'),
    ('stock_transactions','Authenticated users can manage stock transactions'),
    ('suppliers','Authenticated users can manage suppliers')
  ) AS t(tbl, pol) LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', r.pol, r.tbl);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR ALL TO authenticated USING (public.is_warehouse_member(auth.uid())) WITH CHECK (public.is_warehouse_member(auth.uid()))', 'Warehouse staff can manage ' || r.tbl, r.tbl);
  END LOOP;
END $$;